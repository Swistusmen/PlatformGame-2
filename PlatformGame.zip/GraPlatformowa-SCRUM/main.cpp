#include <iostream>
#include "Game.hpp"

using namespace std;

int main()
{
    Game* Gra=new Game;
    Gra->Run();
    cout << "Hello world!" << endl;
    return 0;
}
