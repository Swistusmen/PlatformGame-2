#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <vector>
#include "Units.hpp"
#include "Utilities.hpp"
#include "Commands.hpp"
#include "Game.hpp"
#include <typeinfo>

//problem z platforma- nie wlacza sie tryb spadania jesl nie ma podemna obeiktu- to powazny problem prz platormie

//pomyslec jak niszczyc bombe, gdy ona uderzy, zastanowic sie nad singleton i jak go zrealizowac
// jak sprawic by cos przestac wyswietlac

//Glowne problemy do rozwiazania:
//1.Problem braku spadania
//2.Problem obiektow poruszajacych sie na czyms innym- tych co musza otrzymywac jakies wspolrzedne
//3.Problem Singletona- jak tworzyc i niszczyc obiekty



Game::Game()
{
    Holder.LoadFromFile(ObjectTypes::GroundFloor,"dirt.jpg");
    Holder.LoadFromFile(ObjectTypes::Hero,"player1.jpg");
    Holder.LoadFromFile(ObjectTypes::End,"endingPoint.jpg");
    Holder.LoadFromFile(ObjectTypes::Bomba,"bomb.jpg");
    Holder.LoadFromFile(ObjectTypes::Platforma,"steel.jpg");


    std::unique_ptr<Entity> wsk(new Player(ObjectTypes::Hero,sf::Vector2f{100,100},Holder.GetTexture(ObjectTypes::Hero)));
    Gracz=std::move(wsk);

    std::unique_ptr<Entity> wskk(new Enemy(ObjectTypes::Hero,sf::Vector2f{1500,500},Holder.GetTexture(ObjectTypes::Hero)));
    wrog=std::move(wskk);

    std::unique_ptr<Entity> ptr(new gf::GroundFloor(ObjectTypes::GroundFloor,sf::Vector2f(0,1300),sf::IntRect(0,1300,2800,100),Holder.GetTexture(ObjectTypes::GroundFloor)));
    ziemia=std::move(ptr);

    std::unique_ptr<Entity> platf(new gf::GroundFloor(ObjectTypes::GroundFloor,sf::Vector2f(1000,900),sf::IntRect(1000,900,300,100),Holder.GetTexture(ObjectTypes::GroundFloor)));
    ziemia_wyspa=std::move(platf);

    std::shared_ptr<Observer> obs (new Observer);
    obserwatorzy.push_back(std::move(obs));

    std::unique_ptr<Entity> ptrr(new EndGate(ObjectTypes::End,sf::Vector2f{2000,1200},Holder.GetTexture(ObjectTypes::End)));
    brama=std::move(ptrr);

    //std::unique_ptr<Entity> te(new Bomb(ObjectTypes::Bomba,sf::Vector2f{1000,100},Holder.GetTexture(ObjectTypes::Bomba)));

    std::unique_ptr<Entity> te (new Platform(ObjectTypes::GroundFloor,sf::Vector2f(1800,800),sf::IntRect(1800,800,300,100),Holder.GetTexture(ObjectTypes::Platforma)));
    test=std::move(te);




    brama->SetObserver((obserwatorzy.back()));

    stanGry=GameStates::Play;
}

void Game::DistributeTheCommands(sf::Time & a)
{
        test->AutomaticMove(a);
        Gracz->AutomaticMove(a);
        wrog->AutomaticMove(a);

    while(Orders.IsEmpty()==0)
    {
        command bufor=Orders.pop();
        bufor.GetAFunction()(*Gracz,a);

    }
}

void Game::draw()
{
    test->draw(appwindow);
    ziemia->draw(appwindow);
    ziemia_wyspa->draw(appwindow);
    wrog->draw(appwindow);
    brama->draw(appwindow);
    Gracz->draw(appwindow);
    appwindow.display();
    appwindow.clear();
}

void Game::update()
{
    Collision pozycja;
    //pozycja.typ=ObjectTypes::None;
    //Gracz->react(pozycja);

    /*Collision*/ pozycja=Gracz->DoTheyCover(*ziemia);   //etap wykrycia kolizji
    bool i=0;

    if(pozycja.typ==ObjectTypes::GroundFloor)       //etap reakcji na kolizje
    {
        Gracz->react(pozycja);
        i=1;
    }


    pozycja=Gracz->DoTheyCover(*ziemia_wyspa);
    if(pozycja.typ==ObjectTypes::GroundFloor)       //etap reakcji na kolizje
    {
        Gracz->react(pozycja);
        i=1;
    }

    pozycja=Gracz->DoTheyCover(*test);
    if(pozycja.typ==ObjectTypes::GroundFloor)       //etap reakcji na kolizje
    {
        Gracz->react(pozycja);
    }




    pozycja=brama->DoTheyCover(*Gracz);
    if(pozycja.typ==ObjectTypes::Hero)
    {
        brama->react(pozycja);
    }




     //DO BOMBY
     /*
    pozycja=test->DoTheyCover(*Gracz);
    if(pozycja.typ==ObjectTypes::Hero)
    {
        test->react(pozycja);
    }

    pozycja=test->DoTheyCover(*ziemia);
    if(pozycja.typ==ObjectTypes::GroundFloor)       //etap reakcji na kolizje
    {
        test->react(pozycja);
    }

    pozycja=test->DoTheyCover(*ziemia_wyspa);
    if(pozycja.typ==ObjectTypes::GroundFloor)       //etap reakcji na kolizje
    {
        test->react(pozycja);
    }
    */

    if((*obserwatorzy.front()).WasSomethingObserved())
    {
        std::cout<<"b\n";
        stanGry=(obserwatorzy.front())->ReturnObserwation();
    }

    test->update();
    ziemia_wyspa->update();
     Gracz->update();
     brama->update();                              //etap aktualizacji dancyh
     ziemia->update();
     wrog->update();
    //poziom.CheckCollisions();
    //poziom.update();
}


void Game::Run()
{
    appwindow.create(sf::VideoMode(SZEROKOSCOKNA,WYSOKOSCOKNA,32),"okno");
    sf::Time TimeSinceLastUpdate;
    sf::Clock timer;
    sf::Time DeltaTime=sf::seconds(1.f/20.f);
   // int i=0;

    while(appwindow.isOpen())
    {
        HandleEvent();


            if(stanGry==GameStates::Pause){
            TimeSinceLastUpdate+=timer.restart();
            TimeSinceLastUpdate=TimeSinceLastUpdate%DeltaTime;
            }
            if(stanGry==GameStates::Play){

            //i++;
            //if(i==1000)
             //   delete test;

            TimeSinceLastUpdate+=timer.restart();
            if(TimeSinceLastUpdate>=DeltaTime)
            {
            ProcessInput();

            DistributeTheCommands(TimeSinceLastUpdate);
            update();//funkcja sprawdzajaca kolizje znajduje sie w update, ma byc w kodzie jak najpozniej, to dlatego
            draw();

            TimeSinceLastUpdate-=DeltaTime;
            }
        }
        ProcessEvent();
    }
}

void Game::ProcessInput()
{
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A))
    {
        auto f=[](Entity& obiekt, sf::Time& a){sf::Vector2f wektorek=sf::Vector2f(-1,0);obiekt.MoveEntity(wektorek,a);};
        command bufor {f,ObjectTypes::Hero};
        Orders.push(bufor);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D))
    {
        auto f=[](Entity& obiekt, sf::Time& a){sf::Vector2f wektorek= sf::Vector2f(1,0);obiekt.MoveEntity(wektorek,a);};
        command bufor {f,ObjectTypes::Hero};
        Orders.push(bufor);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
    {
        auto f=[](Entity& obiekt, sf::Time& a){sf::Vector2f wektorek= sf::Vector2f(0,-1);obiekt.MoveEntity(wektorek,a);};
        command bufor {f,ObjectTypes::Hero};
        Orders.push(bufor);
    }
}

void Game::ProcessEvent()
{

    if((stanGry==GameStates::Closing)||(stanGry==GameStates::Winner))
    {
        appwindow.close();
        exit(EXIT_SUCCESS);
    }


}

void Game::HandleEvent()
{
    sf::Event zdarzenie;
   while(appwindow.pollEvent(zdarzenie))
   {
       switch (zdarzenie.type)
       {
           case sf::Event::Closed:
           {
               stanGry=GameStates::Closing;
           }break;
        default:{
        }break;

       }
   }
   if(sf::Keyboard::isKeyPressed(sf::Keyboard::C))
   {
       if(stanGry==GameStates::Play)
        stanGry=GameStates::Pause;
       else if(stanGry==GameStates::Pause)
        stanGry=GameStates::Play;
   }
}
