#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <utility>
#include <map>
#include "Utilities.hpp"

/////////////////////////// OSERWATOR

void Observer::SawSomething(ObjectTypes moj,ObjectTypes obcy)
{
    if((moj==ObjectTypes::End)&&(obcy==ObjectTypes::Hero))
    {
        Detection=1;
        std::cout<<Detection<<" h\n";
        stan=GameStates::Winner;
    }
    std::cout<<WasSomethingObserved()<<"g\n";
}

////////////// Texture Holder

void TextureHolder::LoadFromFile(ObjectTypes przyporzadkowanie,std::string&& pathname)
{
    std::unique_ptr<sf::Texture> wsk (new sf::Texture);
    if(!wsk->loadFromFile(pathname))
    {
        std::cerr<<"Blad we wczytywaniu tekstury z pliku\n";
        exit(EXIT_FAILURE);
    }
    mapka.insert(std::make_pair(przyporzadkowanie,std::move(wsk)));
}

sf::Texture& TextureHolder::GetTexture(ObjectTypes rodzaj)
{
    auto znalezione=mapka.find(rodzaj);
    if(znalezione==mapka.end())
    {
        std::cerr<<"Nie znaleziono tekstury "<<rodzaj<<std::endl;
        exit(EXIT_FAILURE);
    }
    return *znalezione->second;
}
