#include <iostream>
#include <functional>
#include <utility>
#include <string>
#include <vector>
#include <SFML/Graphics.hpp>
#include "Physics.hpp"
#include "Units.hpp"
/*
class Platform:public PasiveEntity,public CellularAutomata{
    GroundFloor(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    GroundFloor(ObjectTypes &&, sf::Vector2f &&, sf::IntRect &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    void react(Collision& a){}
    void update( ) override;
    void AutomaticMove(sf::Time& ) override;
private:
    sf::Vector2f velocity{50,50};
};*/

void Platform::AutomaticMove(sf::Time& dt)
{
    placement=RealizeTheMove(dt);
}

void Platform::update()
{
    sprite.setPosition(placement);
}

Platform::Platform(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):PasiveEntity(std::move(a),std::move(b),c,std::move(d)),CellularAutomata(velocity)
{
    SetRange(sf::Vector2f{500,100},ReturnPosition());
}

Platform::Platform(ObjectTypes && a, sf::Vector2f && b, sf::IntRect && c,sf::Texture& d,sf::Vector2f&& e):PasiveEntity(std::move(a),std::move(b),std::move(c),d,std::move(e)),CellularAutomata(velocity)
{
    SetRange(sf::Vector2f{500,100},ReturnPosition());
}


////////////////////////////// BOMBA

void Bomb::AutomaticMove(sf::Time& dt)
{
    int k=dt.asSeconds()*velocity.y;
    placement.y+=k;
}

Bomb::Bomb(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):ActiveEntity(std::move(a),std::move(b),c,std::move(d)){}

void Bomb::react(Collision& kolizja)
{
    if(kolizja.typ!=ObjectTypes::None)
    {
        //musi sie zniszczyc
        this->~Bomb();
        std::cout<<"Niszczenie\n";
    }
}

void Bomb::update()
{
    sprite.setPosition(placement);
}

/////////////////////////// END GATE
void EndGate::react(Collision& a)
{
    std::cout<<"Reakcja\n";
    if(a.typ==Hero)
        obserwator->SawSomething(typ,a.typ);
}

void EndGate::update()
{
    sprite.setPosition(placement);
}

EndGate::EndGate(ObjectTypes && a, sf::Vector2f &&b,sf::Texture& c,sf::Vector2f&& d ):PasiveEntity(std::move(a),std::move(b),c,std::move(d))
{
    DoIWantAnObserwer=true;
}


///////////////////////////// Enemy
void Enemy::MoveEntity(sf::Vector2f& ,sf::Time& )
{

}

void Enemy::react(Collision& )
{

}

void Enemy::AutomaticMove(sf::Time& dt)
{
    placement=RealizeTheMove(dt);
}

void Enemy::update()
{
    sprite.setPosition(placement);
}

Enemy::Enemy(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):ActiveEntity(std::move(a),std::move(b),c,std::move(d)),CellularAutomata(velocity)
                {
                   SetRange(sf::Vector2f{400,400},ReturnPosition());
                }

//////////////////////////////////// Player
void Player::AutomaticMove( sf::Time& dt)
{
    placement=RealizeTheFall(placement,velocity,dt);
}

void Player::react(Collision& a)
{
    switch(a.typ)
    {
        case ObjectTypes::GroundFloor:{
        placement.x+=a.nachodzenie.x;
        std::cout<<a.nachodzenie.y<<std::endl;
        placement.y+=a.nachodzenie.y;
        if(a.nachodzenie.y<0)
        ChangeState(HumanStates::Stand);
        if(a.nachodzenie.y>0)
        ChangeState(HumanStates::Fall);
        }break;
        case ObjectTypes::None:
            {
                ChangeState(HumanStates::Fall);
            }break;
        default:{
        }break;
    }
}

void Player::update()
{
     sprite.setPosition(placement);
}

void Player::MoveEntity(sf::Vector2f& a,sf::Time& b)
{
    bool isZero;
    a.y!=0?isZero=false:isZero=true;
    if(ReturnHumanState()==HumanStates::Stand)
    placement=RealizeTheMove(placement,velocity,isZero,b);

    if(a.x!=0){
            int c=velocity.x*15;
        int k=c*b.asSeconds()*a.x;
        placement.x+=k;
        if(placement.x<0)
            placement.x=0;
        if(placement.x>SZEROKOSCOKNA-101)
            placement.x=SZEROKOSCOKNA-100;
    }
}

Player::Player(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):ActiveEntity(std::move(a),std::move(b),c,std::move(d))
{
    sprite.setTextureRect(sf::IntRect(0,0,100,100));
velocity.x=POZIOM_GRACZ;
velocity.y=PION_GRACZ;
}

////////////////////////////// GroundFloor
void gf::GroundFloor::update()
{
    sprite.setPosition(placement);
}

void gf::GroundFloor::AutomaticMove(sf::Time& a)
{
}

gf::GroundFloor::GroundFloor(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):PasiveEntity(std::move(a),std::move(b),c,std::move(d)){};

gf::GroundFloor::GroundFloor(ObjectTypes && a, sf::Vector2f && b, sf::IntRect && c,sf::Texture& d,sf::Vector2f&& e):PasiveEntity(std::move(a),std::move(b),std::move(c),d,std::move(e))
{
d.setRepeated(true);
};

/////////////////////// ActiveEntity

ActiveEntity::ActiveEntity(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):Entity(std::move(a),std::move(b))
{
    tekstura=c;
    sprite.setTexture(tekstura);
    //sprite.setScale(std::move(d));
}


///////////////////////// Pasive Entity


void PasiveEntity::MoveEntity(sf::Vector2f& a,sf::Time& b)
{
    placement+=a;
}

PasiveEntity::PasiveEntity(ObjectTypes && a, sf::Vector2f && b,sf::IntRect && c,sf::Texture& d,sf::Vector2f&& e):Entity(std::move(a),std::move(b))
{
    tekstura=d;
    sprite.setTexture(tekstura);
    sprite.setScale(std::move(e));
    sprite.setTextureRect(sf::IntRect(std::move(c)));
    tekstura.setRepeated(true);
}

PasiveEntity::PasiveEntity(ObjectTypes && a, sf::Vector2f && b,sf::Texture& c,sf::Vector2f&& d):Entity(std::move(a),std::move(b))
{
    tekstura=c;
    sprite.setTexture(tekstura);
    sprite.setScale(std::move(d));
}


////////////////// Entity

Entity::~Entity()
{
    std::cout<<"kasowanko\n";

}


void Entity::draw(sf::RenderWindow& appwindow)
{
    appwindow.draw(sprite);
}

Entity::Entity(ObjectTypes && a, sf::Vector2f && b)
{
    typ=std::move(a);
    placement=std::move(b);
    sprite.setPosition(placement);
}

ObjectTypes& Entity::RetTypeOfObject()
{
    return typ;
}

const sf::Vector2f& Entity::ReturnCurrentPlacement()
{
    return sprite.getPosition();
}

const sf::FloatRect Entity::ReturnTheShape()
{
    return sprite.getGlobalBounds();
}

Collision Entity::DoTheyCover(Entity& a)
{
    sf::FloatRect obcy=a.ReturnTheShape();
    sf::FloatRect rodzimy=this->ReturnTheShape();
    sf::Vector2f wektorek(0,0);
    ObjectTypes CoToZaObiekt=ObjectTypes::None;
    if(rodzimy.intersects(obcy)==1)
    {
        std::cout<<this->RetTypeOfObject();
        int Ol=obcy.left;
        int Ot=obcy.top;
        int Or=obcy.width+Ol;
        int Ob=obcy.height+Ot+1;
        int Rl=rodzimy.left;
        int Rt=rodzimy.top;
        int Rr=rodzimy.width+Rl;
        int Rb=rodzimy.height+Rt;
        //warunki ktore dodajemy sa ujemne dlatego ponizej znaki musza byc na odwrot!
        if((Rb-Ob<0)&&(Rt<Ot))//nachodzenie z gory
        {
            //std::cout<<" Nachodzenie z gory\n";
            wektorek.y+=Ot-Rb;// zmiana ob na ot
        }
        else if((Ot-Rb<0)&&(Rt<Ob))//nachodzenie z dolu
        {
           // std::cout<<" Nachodzenie z dolu\n";
            wektorek.y-=(Rt-Ob);
        }
        else if((Or-Rl>0)&&(Rl>Ol))//nachodzenie z lewej strony  ((Ol-Rr<0)&&(Rl>Ol))
        {
            //std::cout<<" Nachodzenie z lewej\n";
            wektorek.x+=Rl-Or;
            wektorek.y=-1;
        }
        else if((Rr-Ol>0)&&(Ol>Rl))//nachodzenie z prawej storny
        {
            //std::cout<<" Nachodzenie z prawej\n";
            wektorek.x-=Rr-Ol;
            wektorek.y=-1;
        }

        CoToZaObiekt=a.RetTypeOfObject();
    }
    Collision kolizja (wektorek,CoToZaObiekt);
    return kolizja;
}

