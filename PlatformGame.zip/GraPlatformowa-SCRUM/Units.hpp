#ifndef UNITS_HPP_INCLUDED
#define UNITS_HPP_INCLUDED



#endif // UNITS_HPP_INCLUDED
#include <iostream>
#include <functional>
#include <utility>
#include <string>
#include <vector>
#include <SFML/Graphics.hpp>
#include "Physics.hpp"
#include <memory>
//#include "Observer.hpp"
#pragma once


class Entity{
public:

virtual void update()=0;

virtual void react(Collision& )=0;//reakcja na wykryte kolizje
virtual void MoveEntity(sf::Vector2f& ,sf::Time& )=0;
virtual void AutomaticMove( sf::Time&)=0;

void draw (sf::RenderWindow& );
ObjectTypes& RetTypeOfObject();
Collision DoTheyCover(Entity& );// funkja sprawdza czy obiekty zachodza, jesli tak zwraca wektor zchodzenia
const sf::Vector2f& ReturnCurrentPlacement();
const sf::FloatRect ReturnTheShape();
sf::Vector2f& ReturnPosition(){return placement;}
bool WantAnObserver(){return DoIWantAnObserwer;}
//void SetObserver(Observer o){obserwator=o;}
void SetObserver(std::shared_ptr<Observer> o){obserwator=o;}

virtual ~Entity();

Entity(ObjectTypes &&, sf::Vector2f &&);// do obiektow pasywynych

protected:
std::shared_ptr<Observer> obserwator;
//Observer obserwator;
bool DoIWantAnObserwer=0;
sf::Sprite sprite;
ObjectTypes typ;
sf::Vector2f placement;
};

class PasiveEntity:public Entity{// obiekty nie wplywajace na gre- bedace nieruchome, badz zalezne w ruchu i dzialaniu
public:
    void MoveEntity(sf::Vector2f &, sf::Time& ) override;
    PasiveEntity(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    PasiveEntity(ObjectTypes &&, sf::Vector2f &&, sf::IntRect &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
protected:
    sf::Texture tekstura;
};

class ActiveEntity:public Entity{// obiekty wykonujace samodzielny ruch
public:
    ActiveEntity(ObjectTypes &&, sf::Vector2f &&,sf::Texture&,sf::Vector2f&&= sf::Vector2f(1,1));
protected:
    sf::Texture tekstura;
};

class Player:public ActiveEntity,public Human{
public:
    Player(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));

    void update() override;
    void MoveEntity(sf::Vector2f& ,sf::Time& ) override;
    void react(Collision& ) override;
    void AutomaticMove(sf::Time&) override;
private:
    sf::Vector2f velocity {200,30};
};

class Enemy:public ActiveEntity,public CellularAutomata{
public:
    void update() override;
    void MoveEntity(sf::Vector2f& ,sf::Time& ) override;
    void react(Collision& ) override;
    void AutomaticMove(sf::Time&) override;

    Enemy(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
private:
sf::Vector2f velocity {100,20};
};

class Bomb:public ActiveEntity{
public:
    void update() override;
    void MoveEntity(sf::Vector2f& ,sf::Time& ) {};
    void react(Collision& ) override;
    void AutomaticMove(sf::Time&) override;

    ~Bomb(){std::cout<<"Destruktor\n";}
    Bomb(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
private:
    sf::Vector2f velocity {0,300};
};

namespace gf{
class GroundFloor:public PasiveEntity{
public:
    GroundFloor(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    GroundFloor(ObjectTypes &&, sf::Vector2f &&, sf::IntRect &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    void react(Collision& a){}
    void update( ) override;
    void AutomaticMove(sf::Time& ) override;
};
}

class EndGate:public PasiveEntity{
public:
    void react(Collision& a);
    void update( ) override;
    void AutomaticMove(sf::Time& ){}
    EndGate(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
};

class Platform:public PasiveEntity,public CellularAutomata{
public:
    Platform(ObjectTypes &&, sf::Vector2f &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    Platform(ObjectTypes &&, sf::Vector2f &&, sf::IntRect &&,sf::Texture& ,sf::Vector2f&&= sf::Vector2f(1,1));
    void react(Collision& a){}
    void update( ) override;
    void AutomaticMove(sf::Time& ) override;
private:
    sf::Vector2f velocity{50,50};
};

